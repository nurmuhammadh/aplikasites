<!DOCTYPE html>
<html>
<head>
	<title><?= $title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/auth.css'); ?>">
</head>
<body>

  
	<form class="card-content" action="<?= base_url('auth/register'); ?>" method="post" enctype="multipart">
		<div class="text-header">
			<h2>Register</h2>
		</div>

		<div class="container">
			<label for="uname"><b>email</b></label>
			<input type="email" name="email" placeholder="Enter Email" required="@rumahweb.co.id">

			<label for="psw"><b>Password</b></label>
			<input type="password" name="password" placeholder="Enter Password" required="number" minlength="12">

      <label for="psw"><b>Tanggal Lahir</b></label>
			<input type="date" name="tanggal_lahir" placeholder="Minimal usia 18 Tahun" required>

			<button type="submit">Register</button>
		</div>
	</form>
  
</body>
</html>