<?php

class M_user extends CI_Model {

	

}